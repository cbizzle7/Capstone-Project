
rm(list = ls())
# Load libraries
library(caret)
library(e1071)
library(MASS)
library(rpart)
library(mlbench)
library(tidyverse)
library(ggExtra)
library(stringr)
library(pROC)
library(knitr)
library(randomForest)
library(corrplot)
library(tibble)
#load in data
#variable names as described in the names file
variable_names <- c("age","workclass","fnlwgt","education", "education.num",
                    "marital.status","occupation","relationship","race",
                    "sex","capital.gain","capital.loss","hours.per.week", 
                    "native.country","income")

adult_train_UCI <- read.csv("adult_train_UCI.csv", header = F, stringsAsFactors = T)
adult_test_UCI <- read.csv("adult_test_UCI.csv", header = F, stringsAsFactors = T)

#Combine the two frames for analysis
adult_income <- rbind(adult_train_UCI, adult_test_UCI)
names(adult_income) <- variable_names
summary(adult_income)



#remove  whites pace from all variables
# Apply the trimws() function to all variables of the data frame
adult_income <- data.frame(lapply(adult_income, trimws))
#replace the values "<=50K." with "<=50K", and >50K.with >50K
#they values to be replaced have a white space before them
adult_income$income[adult_income$income=='<=50K.'] <- "<=50K"
adult_income$income[adult_income$income=='>50K.'] <- ">50K"
#confiming the changes
table(adult_income$income)



#replace the unknown values "?" with NA
adult_income[adult_income=='?'] <- NA
#How many missing values are there
sum(is.na(adult_income))



kable((colSums(is.na(adult_income))), col.names = "Missing values", 
      caption ="Number of missing values per variable")
kable((colMeans(is.na(adult_income)))*100,col.names = "Percentage missing", 
      caption ="percentage of missing values per variable")



#using the na.omit function to remove all missing values
adult_income <- na.omit(adult_income)
# have a peek at the dimensions and observations
glimpse(adult_income)



#create a vector of all numerical variables
nums <- c(1,3,5,11:13)
# Use lapply to apply the as.numeric function to the first two columns
adult_income[,nums] <- lapply(adult_income[, nums], as.numeric)
# Use lapply to apply the as.factor function to the third column
adult_income[, -nums] <- lapply(adult_income[, -nums], as.factor)



#investigating distribution of unique levels for the factor variables.
adult_levels <- lapply(adult_income, unique)
adult_levels_count <- lengths(adult_levels) #unique levels for each variable
adult_levels_count



kable(table(adult_income$workclass)/length(adult_income$workclass) * 100, caption = "Percentage of work class levels")
kable(table(adult_income$marital.status)/length(adult_income$marital.status)*100, caption = "Percentage of marital.status levels")
kable(table(adult_income$race)/length(adult_income$race)*100, caption = "Percentage of race levels")



#Subset the numerical variables into a different data frame
adult_income_num <- adult_income[, nums]
num_cor <- cor(adult_income_num,method = "pearson")
corrplot(num_cor)



#visualization of numeric variables
par(mfrow=c(2,2))
hist(adult_income$age, xlim=c(0,90), main = "Distribution of Age",
        ylab = "Count", xlab = "age", col = "gold")
hist(adult_income$capital.gain, main = "Distribution of capital gain",
        ylab = "Count", xlab = "capital gain", col = "gold")
hist(adult_income$capital.loss, main = "Distribution of capital loss",
        ylab = "Count", xlab = "capital loss", col = "gold")
hist(adult_income$hours.per.week, main = "Distribution of hours per week",
        ylab = "Count", xlab = "Hours per week", col = "gold")



ggplot(adult_income, aes(x=income, y=age, fill=sex)) +  geom_boxplot()+ ggtitle(" Income categories, age and sex") + xlab("Income") + ylab("Age") + removeGrid()+theme_minimal()



ggplot(adult_income, aes(x=income, y=hours.per.week, fill=sex)) +  geom_boxplot()+ ggtitle(" Income categories, working hours and sex") + xlab("Income") + ylab("Week Hours") + removeGrid()+theme_minimal()



ggplot(adult_income, aes(x=income, y=hours.per.week, fill=race)) +  geom_boxplot()+ ggtitle(" Income categories, working hours and race") + xlab("Income") + ylab("Week Hours") + removeGrid()+theme_minimal()



ggplot(adult_income, aes(x=income, y=hours.per.week, fill=marital.status)) +  geom_boxplot()+ ggtitle(" Income categories, working hours and marital status") + xlab("Income") + ylab("Week Hours") + removeGrid()+theme_minimal()



ggplot(adult_income, aes(x=income, y=hours.per.week, fill=workclass)) +  geom_boxplot()+ ggtitle(" Income categories, working hours and workclass") + xlab("Income") + ylab("Week Hours") + removeGrid()+theme_minimal()



# convert the sex variable to a binary variable
adult_income$sex <- ifelse(adult_income$sex=="Male", 1, 0)
#convert the income variable to a binary variable.  
adult_income$income <- ifelse(adult_income$income=="<=50K", 0, 1)
ex_vars <- c(3,5,14)
adult_income <- adult_income[,-ex_vars]



#set a random seed for reproducibility
set.seed(123)
#create a splitting index based on the income variable
training_part <- createDataPartition(adult_income$income, p = 0.75, 
                                     list = FALSE,times = 1)
train_part <- adult_income[training_part,]
test_part <- adult_income[-training_part,]



#distribution in original data set
(table(adult_income$income)/length(adult_income$income))
#distribution in partitions
(table(train_part$income)/length(train_part$income))
(table(test_part$income)/length(test_part$income))



#create a vector of the actual test observations
test_actual_income <- test_part$income
#fit a decision tree with the distribution of the income variable as the prior prob
dt_model <- rpart(factor(income)~., data = train_part,
                  parms = list(prior = c(.75,.25)))
# decision tree predictions
dt_pred <- predict(dt_model, test_part,type = "class")
# accuracy of predictions on unseen data
dt_cm <- confusionMatrix(factor(dt_pred), factor(test_actual_income))



set.seed(123)
# a random forest model using a maximum of 10 nodes per tree and 500 trees
rf_model <- randomForest(factor(income)~., data = train_part, 
                         maxnodes=10, importance=TRUE, ntree=500)
# Random forest model predictions
rf_preds <- predict(rf_model, newdata = test_part, type = "response")
#model accuracy
rf_cm<-confusionMatrix(factor(rf_preds), factor(test_actual_income), positive = "1")



#Importance of random forest predictors
Var_imp <- varImp(rf_model)
Var_imp <-rownames_to_column(Var_imp,"var") #retrieve the factors from being rownames
Var_imp$var<- as.factor(Var_imp$var)
#Plotting the bar chart to compare variables
imp_bar <- ggplot(data = Var_imp) + geom_bar(
  stat = "identity",
  mapping = aes(x = var, y=`1`, fill = var),
  show.legend = FALSE,
  width = 1) + 
  labs(x = NULL, y = NULL)
imp_bar + coord_flip() + theme_minimal()



set.seed(123)
# a random forest model using a maximum of 10 nodes per tree and 500 trees
rf_model2 <- randomForest(factor(income)~workclass+relationship+occupation+
                            marital.status+education+capital.loss+capital.gain, 
                          data = train_part, 
                         maxnodes=10, importance=TRUE, ntree=500)
# Random forest model predictions
rf_preds2 <- predict(rf_model2, newdata = test_part, type = "response")
#model accuracy
rf_cm2<-confusionMatrix(factor(rf_preds2), factor(test_actual_income), positive = "1")



# a generalized linear model
logit_model <- glm(income~., data = train_part)
# Logit model predictions
logit_preds <- predict(logit_model, newdata = test_part)
logit_preds <- ifelse(logit_preds>0.5,"1","0")
#model accuracy
logit_cm<-confusionMatrix(factor(logit_preds), factor(test_actual_income), positive = "1")



kable(dt_cm$overall, col.names = "Value",caption = "Decision Tree testing performance")
kable(rf_cm$overall, col.names = "Value",caption = "Random Forest-all testing performance")
kable(rf_cm2$overall, col.names = "Value",caption = "Random Forest-imp testing performance")
kable(logit_cm$overall, col.names = "Value",caption = "Logit model testing Performance")



# calculate the ROC
dt_ROC <- roc(as.numeric(test_actual_income),
                  as.numeric(as.character(dt_pred)))
logit_ROC <- roc(as.numeric(test_actual_income),
                     as.numeric(as.character(logit_preds)))
rf_ROC <- roc(as.numeric(test_actual_income), 
                  as.numeric(as.character(rf_preds)))
#calculate the AUC
dt_auc <- round(auc(dt_ROC),4) *100
logit_auc <- round(auc(logit_ROC),4)*100
rf_auc <- round(auc(rf_ROC),4)*100

#Plotting AUC (balanced accuracy)
par(mfrow=c(3,1))
plot(logit_ROC, main = "Logistic ROC curve");text(0.5,1, paste0("auc=",logit_auc,"%"))
plot(rf_ROC, main = "Random Forest ROC curve");text(0.5,1, paste0("auc=",rf_auc,"%"))
plot(dt_ROC, main = "Decision tree ROC curve");text(0.5,1, paste0("auc=",dt_auc,"%"))

